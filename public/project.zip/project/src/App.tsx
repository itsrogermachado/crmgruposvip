import { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { Filters } from './components/Filters';
import { ClienteTable } from './components/ClienteTable';
import { ClienteForm } from './components/ClienteForm';
import { ExcelImport } from './components/ExcelImport';
import { clienteService } from './services/clienteService';
import { exportToExcel } from './utils/excelUtils';
import { Cliente, DashboardMetrics } from './types/cliente';

function App() {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [editingCliente, setEditingCliente] = useState<Cliente | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [planoFilter, setPlanoFilter] = useState('');

  useEffect(() => {
    loadClientes();
  }, []);

  const loadClientes = async () => {
    try {
      setLoading(true);
      await clienteService.updateStatus();
      const data = await clienteService.getAll();
      setClientes(data);
    } catch (error) {
      console.error('Erro ao carregar clientes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveCliente = async (clienteData: Omit<Cliente, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      if (editingCliente) {
        await clienteService.update(editingCliente.id, clienteData);
      } else {
        await clienteService.create(clienteData);
      }
      await loadClientes();
      setShowForm(false);
      setEditingCliente(null);
    } catch (error) {
      console.error('Erro ao salvar cliente:', error);
      throw error;
    }
  };

  const handleDeleteCliente = async (id: string) => {
    try {
      await clienteService.delete(id);
      await loadClientes();
    } catch (error) {
      console.error('Erro ao deletar cliente:', error);
      alert('Erro ao deletar cliente');
    }
  };

  const handleEditCliente = (cliente: Cliente) => {
    setEditingCliente(cliente);
    setShowForm(true);
  };

  const handleImportClientes = async (data: Omit<Cliente, 'id' | 'created_at' | 'updated_at'>[]) => {
    try {
      await clienteService.importClientes(data);
      await loadClientes();
    } catch (error) {
      console.error('Erro ao importar clientes:', error);
      throw error;
    }
  };

  const handleExportClientes = () => {
    exportToExcel(filteredClientes, 'clientes_vip');
  };

  const filteredClientes = useMemo(() => {
    return clientes.filter(cliente => {
      const matchesSearch = searchTerm === '' ||
        cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cliente.numero.includes(searchTerm) ||
        cliente.discord.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === '' || cliente.status === statusFilter;
      const matchesPlano = planoFilter === '' || cliente.plano === planoFilter;

      return matchesSearch && matchesStatus && matchesPlano;
    });
  }, [clientes, searchTerm, statusFilter, planoFilter]);

  const planos = useMemo(() => {
    return Array.from(new Set(clientes.map(c => c.plano))).sort();
  }, [clientes]);

  const metrics: DashboardMetrics = useMemo(() => {
    const totalClientes = clientes.length;
    const clientesAtivos = clientes.filter(c => c.status === 'ativo').length;
    const clientesVencidos = clientes.filter(c => c.status === 'vencido').length;
    const proximosVencimento = clientes.filter(c => c.status === 'proximo_vencimento').length;
    const faturamentoMensal = clientes.reduce((sum, c) => sum + c.preco, 0);
    const lucroEsperado = clientes
      .filter(c => c.status === 'ativo' || c.status === 'proximo_vencimento')
      .reduce((sum, c) => sum + c.preco, 0);

    return {
      totalClientes,
      clientesAtivos,
      clientesVencidos,
      proximosVencimento,
      faturamentoMensal,
      lucroEsperado
    };
  }, [clientes]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header
        onImport={() => setShowImport(true)}
        onExport={handleExportClientes}
        onAddCliente={() => {
          setEditingCliente(null);
          setShowForm(true);
        }}
        onRefresh={loadClientes}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Dashboard metrics={metrics} />

        <Filters
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          planoFilter={planoFilter}
          onPlanoFilterChange={setPlanoFilter}
          planos={planos}
        />

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <ClienteTable
            clientes={filteredClientes}
            onEdit={handleEditCliente}
            onDelete={handleDeleteCliente}
          />
        )}
      </div>

      {showForm && (
        <ClienteForm
          cliente={editingCliente}
          onSave={handleSaveCliente}
          onClose={() => {
            setShowForm(false);
            setEditingCliente(null);
          }}
        />
      )}

      {showImport && (
        <ExcelImport
          onImport={handleImportClientes}
          onClose={() => setShowImport(false)}
        />
      )}
    </div>
  );
}

export default App;
