export interface Cliente {
  id: string;
  nome: string;
  numero: string;
  discord: string;
  plano: string;
  preco: number;
  data_entrada: string;
  data_vencimento: string;
  status: 'ativo' | 'vencido' | 'proximo_vencimento';
  observacoes: string;
  created_at?: string;
  updated_at?: string;
}

export interface ClienteImport {
  Nome: string;
  Numero: string;
  Discord?: string;
  Preco: number;
  Data: string;
  Plano: string;
}

export interface DashboardMetrics {
  totalClientes: number;
  clientesAtivos: number;
  clientesVencidos: number;
  proximosVencimento: number;
  faturamentoMensal: number;
  lucroEsperado: number;
}
