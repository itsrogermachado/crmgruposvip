import { supabase } from '../lib/supabase';
import { Cliente } from '../types/cliente';

export const clienteService = {
  async getAll(): Promise<Cliente[]> {
    const { data, error } = await supabase
      .from('clientes')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getById(id: string): Promise<Cliente | null> {
    const { data, error } = await supabase
      .from('clientes')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async create(cliente: Omit<Cliente, 'id' | 'created_at' | 'updated_at'>): Promise<Cliente> {
    const { data, error } = await supabase
      .from('clientes')
      .insert([cliente])
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async update(id: string, cliente: Partial<Cliente>): Promise<Cliente> {
    const { data, error } = await supabase
      .from('clientes')
      .update(cliente)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('clientes')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async importClientes(clientes: Omit<Cliente, 'id' | 'created_at' | 'updated_at'>[]): Promise<Cliente[]> {
    const { data, error } = await supabase
      .from('clientes')
      .upsert(clientes, { onConflict: 'numero' })
      .select();

    if (error) throw error;
    return data || [];
  },

  async updateStatus(): Promise<void> {
    const hoje = new Date().toISOString().split('T')[0];
    const proximos7Dias = new Date();
    proximos7Dias.setDate(proximos7Dias.getDate() + 7);
    const dataProximos = proximos7Dias.toISOString().split('T')[0];

    await supabase
      .from('clientes')
      .update({ status: 'vencido' })
      .lt('data_vencimento', hoje);

    await supabase
      .from('clientes')
      .update({ status: 'proximo_vencimento' })
      .gte('data_vencimento', hoje)
      .lte('data_vencimento', dataProximos);

    await supabase
      .from('clientes')
      .update({ status: 'ativo' })
      .gt('data_vencimento', dataProximos);
  }
};
