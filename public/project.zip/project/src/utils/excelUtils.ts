import * as XLSX from 'xlsx';
import { Cliente, ClienteImport } from '../types/cliente';

export const readExcelFile = (file: File): Promise<ClienteImport[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json<ClienteImport>(worksheet);

        resolve(jsonData);
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = () => reject(new Error('Erro ao ler arquivo'));
    reader.readAsBinaryString(file);
  });
};

export const validateImportData = (data: ClienteImport[]): { valid: ClienteImport[]; errors: string[] } => {
  const valid: ClienteImport[] = [];
  const errors: string[] = [];

  data.forEach((row, index) => {
    const rowErrors: string[] = [];

    if (!row.Nome || row.Nome.trim() === '') {
      rowErrors.push(`Linha ${index + 2}: Nome vazio`);
    }
    if (!row.Numero || row.Numero.toString().trim() === '') {
      rowErrors.push(`Linha ${index + 2}: Número vazio`);
    }
    if (!row.Plano || row.Plano.trim() === '') {
      rowErrors.push(`Linha ${index + 2}: Plano vazio`);
    }
    if (!row.Preco || isNaN(Number(row.Preco))) {
      rowErrors.push(`Linha ${index + 2}: Preço inválido`);
    }
    if (!row.Data) {
      rowErrors.push(`Linha ${index + 2}: Data vazia`);
    }

    if (rowErrors.length > 0) {
      errors.push(...rowErrors);
    } else {
      valid.push(row);
    }
  });

  return { valid, errors };
};

export const convertImportToCliente = (importData: ClienteImport[]): Omit<Cliente, 'id' | 'created_at' | 'updated_at'>[] => {
  return importData.map(row => {
    const dataEntrada = parseExcelDate(row.Data);
    const dataVencimento = new Date(dataEntrada);
    dataVencimento.setDate(dataVencimento.getDate() + 30);

    return {
      nome: row.Nome.trim(),
      numero: row.Numero.toString().trim(),
      discord: row.Discord?.toString().trim() || '',
      plano: row.Plano.trim(),
      preco: Number(row.Preco),
      data_entrada: dataEntrada.toISOString().split('T')[0],
      data_vencimento: dataVencimento.toISOString().split('T')[0],
      status: 'ativo' as const,
      observacoes: ''
    };
  });
};

const parseExcelDate = (excelDate: string | number): Date => {
  if (typeof excelDate === 'number') {
    const date = new Date((excelDate - 25569) * 86400 * 1000);
    return date;
  }

  const dateFormats = [
    /^\d{2}\/\d{2}\/\d{4}$/,
    /^\d{4}-\d{2}-\d{2}$/,
    /^\d{2}-\d{2}-\d{4}$/
  ];

  for (const format of dateFormats) {
    if (format.test(excelDate)) {
      const parts = excelDate.split(/[-/]/);
      if (excelDate.includes('/')) {
        return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
      } else if (parts[0].length === 4) {
        return new Date(excelDate);
      } else {
        return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
      }
    }
  }

  return new Date(excelDate);
};

export const exportToExcel = (clientes: Cliente[], filename: string = 'clientes'): void => {
  const exportData = clientes.map(cliente => ({
    Nome: cliente.nome,
    Numero: cliente.numero,
    Discord: cliente.discord,
    Plano: cliente.plano,
    Preco: cliente.preco,
    'Data Entrada': cliente.data_entrada,
    'Data Vencimento': cliente.data_vencimento,
    Status: cliente.status,
    Observacoes: cliente.observacoes
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Clientes');

  XLSX.writeFile(workbook, `${filename}_${new Date().toISOString().split('T')[0]}.xlsx`);
};
