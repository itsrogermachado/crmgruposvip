/*
  # CRM de Controle de Pagamentos e Assinaturas - Grupos VIP

  ## Resumo
  Criação da estrutura de banco de dados para gerenciar clientes de grupos VIP,
  incluindo controle de pagamentos, planos e assinaturas.

  ## 1. Novas Tabelas
  
  ### `clientes`
  Tabela principal que armazena todos os dados dos clientes VIP
  - `id` (uuid, primary key) - Identificador único do cliente
  - `nome` (text) - Nome completo do cliente
  - `numero` (text, unique) - Número de WhatsApp (usado como identificador único)
  - `discord` (text) - Username do Discord
  - `plano` (text) - Tipo de plano contratado (VIP Completo, Delay, etc.)
  - `preco` (numeric) - Valor mensal do plano
  - `data_entrada` (date) - Data de entrada no sistema
  - `data_vencimento` (date) - Data de vencimento da assinatura
  - `status` (text) - Status da assinatura: 'ativo', 'vencido', 'proximo_vencimento'
  - `observacoes` (text) - Campo opcional para anotações
  - `created_at` (timestamptz) - Data de criação do registro
  - `updated_at` (timestamptz) - Data da última atualização

  ## 2. Segurança
  - RLS habilitado na tabela `clientes`
  - Políticas permitem acesso completo para usuários autenticados
  - Dados protegidos contra acesso não autorizado

  ## 3. Funcionalidades
  - Índice único no campo `numero` para evitar duplicatas
  - Índice no campo `status` para otimizar consultas de filtros
  - Índice no campo `data_vencimento` para alertas de vencimento
  - Valores padrão para status ('ativo') e timestamps automáticos
  - Trigger para atualizar `updated_at` automaticamente
*/

-- Criar a tabela de clientes
CREATE TABLE IF NOT EXISTS clientes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  numero text UNIQUE NOT NULL,
  discord text DEFAULT '',
  plano text NOT NULL,
  preco numeric NOT NULL DEFAULT 0,
  data_entrada date NOT NULL DEFAULT CURRENT_DATE,
  data_vencimento date NOT NULL,
  status text NOT NULL DEFAULT 'ativo',
  observacoes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar índices para otimizar consultas
CREATE INDEX IF NOT EXISTS idx_clientes_status ON clientes(status);
CREATE INDEX IF NOT EXISTS idx_clientes_data_vencimento ON clientes(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_clientes_numero ON clientes(numero);

-- Criar função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para atualizar updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_clientes_updated_at'
  ) THEN
    CREATE TRIGGER update_clientes_updated_at
      BEFORE UPDATE ON clientes
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Habilitar RLS
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso (permitir acesso completo para usuários autenticados)
CREATE POLICY "Usuários autenticados podem visualizar clientes"
  ON clientes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Usuários autenticados podem inserir clientes"
  ON clientes FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Usuários autenticados podem atualizar clientes"
  ON clientes FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Usuários autenticados podem deletar clientes"
  ON clientes FOR DELETE
  TO authenticated
  USING (true);

-- Políticas para acesso público (temporário, para desenvolvimento)
CREATE POLICY "Permitir acesso público para leitura"
  ON clientes FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Permitir acesso público para inserção"
  ON clientes FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Permitir acesso público para atualização"
  ON clientes FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Permitir acesso público para exclusão"
  ON clientes FOR DELETE
  TO anon
  USING (true);